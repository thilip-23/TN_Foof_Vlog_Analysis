
# 🍽️ Tamil Nadu Food Vlog Analysis

Analyze the growing trend of food vlogs in Tamil Nadu using real YouTube-style data.
This project combines data generation, cleaning, visualization, and insights into one cohesive story.

## 🔧 Tools Used
- Python (Simulated scraping)
- Power BI (Interactive dashboard)
- Excel (Data cleanup)
- GitHub (Version control)

## 📊 Dashboard Includes:
- Total Views, Likes, Comments (KPIs)
- Top Channels by Views
- Popular Food Categories
- City-wise Vlog Reach
- Monthly Upload Trends
- Channel/City/Category Slicers

## 📁 Files Included
- `tamilnadu_food_vlogs_data.csv` – Clean dataset
- `tamilnadu_food_vlogs_data.xlsx` – For dashboard import
- `food_vlog_scraper.py` – Python scraper (placeholder)
- `food_vlog_dashboard.pbix` – Power BI dashboard
- `Food_Vlog_Dashboard_Preview.png` – Snapshot of visual
